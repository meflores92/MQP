/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CoderTimeAPI.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 18-Jan-2022 10:16:38
 */

/* Include Files */
#include "CoderTimeAPI.h"
#include "get_tic_data.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void freq_not_empty_init(void)
{
  freq_not_empty = false;
}

/*
 * File trailer for CoderTimeAPI.c
 *
 * [EOF]
 */

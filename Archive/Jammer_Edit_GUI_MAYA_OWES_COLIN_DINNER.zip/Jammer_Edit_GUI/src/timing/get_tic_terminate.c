/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: get_tic_terminate.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 18-Jan-2022 10:16:38
 */

/* Include Files */
#include "get_tic_terminate.h"
#include "get_tic_data.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void get_tic_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_get_tic = false;
}

/*
 * File trailer for get_tic_terminate.c
 *
 * [EOF]
 */

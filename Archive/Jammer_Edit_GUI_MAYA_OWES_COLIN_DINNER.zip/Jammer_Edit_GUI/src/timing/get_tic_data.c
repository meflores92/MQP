/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: get_tic_data.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 18-Jan-2022 10:16:38
 */

/* Include Files */
#include "get_tic_data.h"

/* Variable Definitions */
double freq;

boolean_T freq_not_empty;

boolean_T isInitialized_get_tic = false;

/*
 * File trailer for get_tic_data.c
 *
 * [EOF]
 */

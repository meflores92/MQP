/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: get_tic_terminate.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 18-Jan-2022 10:16:38
 */

#ifndef GET_TIC_TERMINATE_H
#define GET_TIC_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void get_tic_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for get_tic_terminate.h
 *
 * [EOF]
 */
